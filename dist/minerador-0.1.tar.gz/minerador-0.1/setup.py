from setuptools import setup

setup(name='minerador',
      version='0.1',
      description='Use of BDD in Open Source projects on github',
      url='http://github.com/ggpsgeorge/minerador',
      author='ggpsgeorge',
      author_email='ggpsgeorge@gmail.com',
      license='MIT',
      packages=['minerador'],
      zip_safe=False)